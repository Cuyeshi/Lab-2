﻿

namespace LibraryForMatrix
{
    /// <summary>
    /// Класс, в котором находятся данные косающиеся матрицы, методы и операции, совершаемые над матрицами. 
    /// </summary>
    public class Matrixs
    {
        /// <summary>
        /// Переменная, хранящая количество строк матрицы.
        /// </summary>
        public int Line;

        /// <summary>
        /// Переменная, хранящая количество столбцов матрицы.
        /// </summary>
        public int Column;

        /// <summary>
        /// Двумерный массив, хранящий элементы матрицы.
        /// </summary>
        public double[,] Value = new double[1000, 1000];
        
        /// <summary>
        /// Конструктор пустой матрицы.
        /// </summary>
        public Matrixs()
        {
            this.Line = 0;
            this.Column = 0;
            this.Value[Line, Column] = 0;
        }

        /// <summary>
        /// Конструктор матрицы по вводимым данным.
        /// </summary>
        /// <param name="line"></param>
        /// <param name="column"></param>
        /// <param name="values"></param>
        public Matrixs(int line, int column, double[,] values)
        {
            this.Line = line;
            this.Column = column;
            int stepColumn = 0;

            for (int stepLine = 0; stepLine < line; stepLine++)
            {
                for (stepColumn = 0; stepColumn < column; stepColumn++)
                    Value[stepLine, stepColumn] = values[stepLine, stepColumn];
            }
        }

        /// <summary>
        /// Операция умножения матрицы на матрицу.
        /// </summary>
        /// <param name="A"></param>
        /// <param name="B"></param>
        /// <returns></returns>
        public static Matrixs operator *(Matrixs A, Matrixs B)
        {
            if (A.Column == B.Line)
            {
                int stepLineA = 0, stepColumnB = 0, stepColumnA = 0, stepLineB = 0;
                Matrixs C = new Matrixs();
                C.Line = A.Line;
                C.Column = B.Column;
                while (stepLineA < A.Line)
                {
                    stepColumnB = 0;
                    while (stepColumnB < B.Column)
                    {
                        stepColumnA = 0; stepLineB = 0;
                        while (stepColumnA < A.Column)
                        {
                            C.Value[stepLineA, stepColumnB] = C.Value[stepLineA, stepColumnB] + A.Value[stepLineA, stepColumnA] * B.Value[stepLineB, stepColumnB];
                            stepColumnA++;
                            stepLineB++;
                        }
                        stepColumnB++;
                    }
                    stepLineA++;
                }

                return C;
            }
            Matrixs D = new Matrixs();
            return D;
        }
        
        /// <summary>
        /// Операция умножения матрицы на число.
        /// </summary>
        /// <param name="number"></param>
        /// <param name="A"></param>
        /// <returns></returns>
        public static Matrixs operator *(double number, Matrixs A)
        {
            int stepLine = 0, stepColumn = 0;
            Matrixs C = new Matrixs();
            C.Line = A.Line;
            C.Column = A.Column;

            for (stepLine = 0; stepLine < A.Line; stepLine++)
            {
                for (stepColumn = 0; stepColumn < A.Column; stepColumn++)
                    C.Value[stepLine, stepColumn] = A.Value[stepLine, stepColumn] * number;
            }

            return C;
        }
        
        
    }
}